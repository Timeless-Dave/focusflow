import React from 'react'

const Pill = ({children}) => (
  <span className="pill">{children}</span>
)

const FeatureCard = ({title, desc, tone}) => (
  <div className={`card ${tone}`}>
    <h4>{title}</h4>
    <p>{desc}</p>
  </div>
)

export default function App(){
  return (
    <div className="page">
      <div className="shell">
        <header className="nav">
          <div className="brand">
            <span className="logo">◐</span> focusflow
          </div>
          <nav>
            <a>Features</a>
            <a>How it works</a>
            <a>Training</a>
            <a>Pricing</a>
            <a>Blog</a>
          </nav>
          <button className="btn primary">Register</button>
        </header>

        <section className="hero">
          <div>
            <h1>
              Teach with <Pill>Focus</Pill> <br/>
              Not <Pill>Friction</Pill>
            </h1>
            <p className="lead">
              FocusFlow is an AI-powered platform designed to help elementary and middle school teachers support students with ADHD in the classroom. We help teachers redesign lessons around how attention works.
            </p>
            <div className="cta">
              <button className="btn ghost">Get Started</button>
              <button className="btn link">▶ Watch Demo</button>
            </div>
          </div>
          <div className="hero-art">
            <div className="blob yellow"></div>
            <div className="photo main"></div>
            <div className="shape pink"></div>
            <div className="shape green"></div>
          </div>
        </section>

        <section className="split">
          <div className="split-media">
            <div className="media-bg"></div>
            <div className="photo side"></div>
          </div>
          <div>
            <h2>Preview Mode <Pill>Live</Pill><br/>and take control of ADHD-friendly lessons.</h2>
            <p>Upload a PDF or pick a topic. FocusFlow generates an ADHD-tailored lesson with story build-up, visual supports, simplified worksheets, movement breaks and check-ins. Preview, edit, then launch Live Mode.</p>
          </div>
        </section>

        <section className="subjects">
          <h3>Which classroom moments can FocusFlow support?</h3>
          <div className="grid3">
            <FeatureCard tone="lilac" title="Lesson Planning" desc="Generate lessons using students' hyperfocus interests like dinosaurs, music or movement." />
            <FeatureCard tone="peach" title="Live Classroom Recovery" desc="Detect disruption and surface instant redirection strategies to teacher tablet and board." />
            <FeatureCard tone="mint" title="Parent Communication" desc="Send practical next steps, not just reminders. E.g. 'Do problems 7-10 with 10-min timer.'" />
          </div>
        </section>
      </div>

      <div className="dark">
        <div className="shell dark-inner">
          <div>
            <h3>Get Real-Time Support for Live Teaching</h3>
            <p>Live Mode updates instantly when attention drops. Verbal instructions become simple written steps for students.</p>
            <button className="btn light">Contact Us</button>
          </div>
          <div className="photo dark-photo"></div>
        </div>
      </div>

      <div className="shell">
        <section className="features">
          <h3>Core Features</h3>
          <div className="feat-grid">
            <div><b>1. AI Lesson Coach</b><br/>Teacher Preview + Live Mode with hyperfocus incorporation.</div>
            <div><b>2. Live Recovery Mode</b><br/>Auto-suggests strategies on disruption, updates board.</div>
            <div><b>3. Bot Feature</b><br/>Talk to Focus bot to design daily plans for students.</div>
            <div><b>4. Parent Hub</b><br/>Clear daily updates with practical steps.</div>
            <div><b>5. Tools</b><br/>Planners, Pomodoro, Checklist, Rewards.</div>
            <div><b>6. ADHD Training</b><br/>Short videos, scripts, strategy cards with incentives.</div>
            <div><b>7. After-Class Summary</b><br/>Student yes/no check, progress tracker, catch-up scheduling.</div>
            <div><b>Homeschool Option</b><br/>Simplified tab for homeschool families.</div>
          </div>
        </section>

        <section className="split">
          <div className="split-media small">
            <div className="media-bg yellow"></div>
            <div className="photo side small"></div>
          </div>
          <div>
            <h3>Making Classrooms Calm and Creative Future</h3>
            <ul className="checks">
              <li>Critical Solutions</li>
              <li>Creativity</li>
              <li>Digital Literacy</li>
              <li>Communication</li>
            </ul>
          </div>
        </section>

        <section className="subscribe">
          <h4>Subscribe for Offer Updates</h4>
          <div className="sub-box">
            <input placeholder="Enter Mail Address" />
            <button className="btn primary small">Enroll Now</button>
          </div>
        </section>

        <footer>© 2026 FocusFlow. Built for teachers, loved by students.</footer>
      </div>
    </div>
  )
}
